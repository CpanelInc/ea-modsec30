#!/bin/sh
set -e
autoreconf -i --force
rm -rf autom4te.cache
